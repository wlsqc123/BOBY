#include "stdafx.h"
#include "D3D12Math.h"

